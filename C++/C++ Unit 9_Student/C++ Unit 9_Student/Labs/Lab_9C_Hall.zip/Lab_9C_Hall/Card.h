struct Card{
	char B; //Blue
	char R; //Red
	char G; //Green
	char Y; //Yellow
	char color = B;
	int value = 3;   //Number -5 to 9
};
