#include <iostream>
using namespace std;
#include "Card.h"

void printCard(Card);

int main(){
	
};

void printCard(Card){
	cout << "Color = " << Card.color << "Value = " << Card.value << endl;
}
