#include <iostream>
using namespace std;

struct Point 
{
	double xCord;
	double yCord;
};

