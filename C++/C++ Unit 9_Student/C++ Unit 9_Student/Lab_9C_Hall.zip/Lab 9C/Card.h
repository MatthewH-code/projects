struct Card{
	char color;
	int value;   //Number -5 to 9
};
